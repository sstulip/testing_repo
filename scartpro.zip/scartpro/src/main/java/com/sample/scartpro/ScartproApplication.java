package com.sample.scartpro;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ScartproApplication {

	public static void main(String[] args) {
		SpringApplication.run(ScartproApplication.class, args);
	}

}
